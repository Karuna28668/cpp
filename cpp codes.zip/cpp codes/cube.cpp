#include <iostream>
using namespace std;
 
// Function declaration
int cube(int num);
 
 
int main()
{
    int num;
    int c;
 
    //Inputting number from user
    cout<<"Enter any number: "<<endl;
    cin>>num;
 
    c = cube(num);
 
    cout<<"Cube of " <<num << " is "<<c;
 
    return 0;
}
 
//Function to find cube of any number
int cube(int num)
{
    return (num * num * num);
}
