#include<iostream>
using namespace std;
class Calculator
{
    public:
    int num1;
    int num2;
    
    void setinput(int a, int b)
    {
        num1 = a;
        num2 = b;
    }
    // addition function
    int add()
    {
        return num1+num2;
    }
    // substraction function
    int sub()
    {
        return num1-num2;
    }
    // multiplication function
    int mul()
    {
        return num1*num2;
    }
    // division function
    float div()
    {
        return num1/num2;
    }
};

int main()
{
    int op,a,b;
    cout <<"which operation you want to perform" << endl; 
    cout << "1.addition" << endl;
    cout << "2.substraction" << endl;
    cout << "3.multiplication" << endl;
    cout << "4.division" << endl;
    cin >> op;
    Calculator obj1;
    cout << "enter numbers: "<< endl;
    cin >> a >>b;
    obj1.setinput(a,b);
    switch(op)
    {
        case 1:
        cout << "the sum of inputs is: " << obj1.add() << endl;
        break;
        
        case 2:
        cout << "substraction of inputs is: "<< obj1.sub() << endl;
        break;
        
        case 3:
        cout << "multiplication of inputs is: "<< obj1.mul() << endl;
        break;
        
        case 4:
        cout << "division of inputs is: "<< obj1.div() << endl;
        break;
    }
    return 0;
}
