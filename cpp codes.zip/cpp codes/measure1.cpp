#include<iostream>
using namespace std;
class measure
{
public:
int height;
int length;
int width;

int area()
{
return 2*(length+width);
}

int volume()
{
return length*width*height;
}

void setinput(int l,int w,int h)
{
length = l;
width = w;
height = h;
}
};

int main()
{
int h,l,w;
cin>> l >> w >> h;
measure obj1;
measure obj2;
obj1.setinput(l,w,h);
obj2.setinput(l,w,h);

cout<< "length= "<< obj1.length << ",  "<<"width= " << obj1.width << endl;
cout<< "the area of rectangle is: "<< obj1.area() << endl;

cout<< "length= "<< obj2.length << ", "<<"width= " << obj2.width << ", "<<"height= " << obj2.height << endl;
cout<< "the volume of rectangle is: "<< obj2.volume();
}
