// operator overloading using friend function
#include<iostream>
using namespace std;

class  complex
{
int real, img;

public:

// default contructor
complex()
{
real =0;
img =0;
}

//parameterised const
complex(int x, int y)
{
real = x;
img = y;
}


//display function
void display()
{
cout << "the real part: "<< real << " and img part: " << img << endl << endl;
}

//operator overloading using friend function
friend complex operator +(complex, complex);

/*
// overload the '+operator'
complex operator +(complex ob)
{
complex temp;
temp.real = real + ob.real;
temp.img = img + ob.img;
return temp;
}
*/

complex operator -(complex ob)
{
complex temp;
temp.real = real - ob.real;
temp.img = img - ob.img;
return temp;
}

complex operator *(complex ob)
{
complex temp;
temp.real = real * ob.real;
temp.img = img * ob.img;
return temp;
}

complex operator /(complex ob)
{
complex temp;
temp.real = real / ob.real;
temp.img = img / ob.img;
return temp;
}

complex operator ==(complex ob)
{
if (real == ob.real && img == ob.img)
{
cout << "both are equal";
}
else
{
cout << "not equal";
}
}

void operator -();
};

void complex::operator-()
{
real = -real;
img = -img;
}

complex operator +(complex obj1, complex obj2)
{
complex temp;
temp.real = obj1.real + obj2.real;
temp.img = obj1.img + obj2.img;
return temp;
}

int main()
{
complex c1(1,2),c2(5,6);
c1.display();
c2.display();
-c1;
c1.display();

// overload the '+operator'
cout << "addition: " << endl;
complex c3;
c3 = c1+c2;
c3.display();

// overload the '-operator'
cout << "substraction: " << endl;
complex c4;
c4 = c1-c2;
c4.display();

// overload the '*operator'
cout << "multiplication: " << endl;
complex c5;
c5 = c1*c2;
c5.display();

// overload the '/operator'
cout << "division: " << endl;
complex c6;
c6 = c1/c2;
c6.display();



return 0;
}

